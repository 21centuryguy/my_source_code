from jacktest import jack
jack.jackjack()