def jackjack():
	print "jack"*100

jackjack()